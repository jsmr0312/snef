using UnityEngine;

public class GuardarPersonaje : MonoBehaviour
{
    public bool personaje1, personaje2, personaje3, personaje4, personaje5, personaje6,
                personaje7, personaje8, personaje9, personaje10, personaje11, personaje12;

    void Start()
    {
        // Carga legacy
        personaje1 = PlayerPrefs.GetInt("personaje1Select", 0) == 1;
        personaje2 = PlayerPrefs.GetInt("personaje2Select", 0) == 1;
        personaje3 = PlayerPrefs.GetInt("personaje3Select", 0) == 1;
        personaje4 = PlayerPrefs.GetInt("personaje4Select", 0) == 1;
        personaje5 = PlayerPrefs.GetInt("personaje5Select", 0) == 1;
        personaje6 = PlayerPrefs.GetInt("personaje6Select", 0) == 1;
        personaje7 = PlayerPrefs.GetInt("personaje7Select", 0) == 1;
        personaje8 = PlayerPrefs.GetInt("personaje8Select", 0) == 1;
        personaje9 = PlayerPrefs.GetInt("personaje9Select", 0) == 1;
        personaje10 = PlayerPrefs.GetInt("personaje10Select", 0) == 1;
        personaje11 = PlayerPrefs.GetInt("personaje11Select", 0) == 1;
        personaje12 = PlayerPrefs.GetInt("personaje12Select", 0) == 1;

        // Si ninguno est� seleccionado, activar el 1 por defecto
        if (!personaje1 && !personaje2 && !personaje3 && !personaje4 &&
            !personaje5 && !personaje6 && !personaje7 && !personaje8 &&
            !personaje9 && !personaje10 && !personaje11 && !personaje12)
        {
            personaje1 = true;
            Guardar();
        }
        MostrarSeleccionado();
    }

    // Botones UI
    public void Personaje1() { Seleccionar(1); }
    public void Personaje2() { Seleccionar(2); }
    public void Personaje3() { Seleccionar(3); }
    public void Personaje4() { Seleccionar(4); }
    public void Personaje5() { Seleccionar(5); }
    public void Personaje6() { Seleccionar(6); }
    public void Personaje7() { Seleccionar(7); }
    public void Personaje8() { Seleccionar(8); }
    public void Personaje9() { Seleccionar(9); }
    public void Personaje10() { Seleccionar(10); }
    public void Personaje11() { Seleccionar(11); }
    public void Personaje12() { Seleccionar(12); }

    void Seleccionar(int index)
    {
        // Solo cambia flags y guarda selecci�n local (no manda m�tricas)
        personaje1 = personaje2 = personaje3 = personaje4 =
        personaje5 = personaje6 = personaje7 = personaje8 =
        personaje9 = personaje10 = personaje11 = personaje12 = false;

        switch (index)
        {
            case 1: personaje1 = true; break;
            case 2: personaje2 = true; break;
            case 3: personaje3 = true; break;
            case 4: personaje4 = true; break;
            case 5: personaje5 = true; break;
            case 6: personaje6 = true; break;
            case 7: personaje7 = true; break;
            case 8: personaje8 = true; break;
            case 9: personaje9 = true; break;
            case 10: personaje10 = true; break;
            case 11: personaje11 = true; break;
            case 12: personaje12 = true; break;
        }

        Guardar();
        AvatarSelectionBridge.SetSelectedIndexToPrefs(index);
    }

    public void Guardar()
    {
        PlayerPrefs.SetInt("personaje1Select", personaje1 ? 1 : 0);
        PlayerPrefs.SetInt("personaje2Select", personaje2 ? 1 : 0);
        PlayerPrefs.SetInt("personaje3Select", personaje3 ? 1 : 0);
        PlayerPrefs.SetInt("personaje4Select", personaje4 ? 1 : 0);
        PlayerPrefs.SetInt("personaje5Select", personaje5 ? 1 : 0);
        PlayerPrefs.SetInt("personaje6Select", personaje6 ? 1 : 0);
        PlayerPrefs.SetInt("personaje7Select", personaje7 ? 1 : 0);
        PlayerPrefs.SetInt("personaje8Select", personaje8 ? 1 : 0);
        PlayerPrefs.SetInt("personaje9Select", personaje9 ? 1 : 0);
        PlayerPrefs.SetInt("personaje10Select", personaje10 ? 1 : 0);
        PlayerPrefs.SetInt("personaje11Select", personaje11 ? 1 : 0);
        PlayerPrefs.SetInt("personaje12Select", personaje12 ? 1 : 0);

        // �ndice unificado e indicador de que ya hay selecci�n
        int idx = AvatarSelectionBridge.GetSelectedIndexFromBools(
            personaje1, personaje2, personaje3, personaje4, personaje5, personaje6,
            personaje7, personaje8, personaje9, personaje10, personaje11, personaje12
        );
        if (idx > 0) AvatarSelectionBridge.SetSelectedIndexToPrefs(idx);
        PlayerPrefs.SetInt("avatar_selected", 1);

        PlayerPrefs.Save();
        MostrarSeleccionado();
    }

    void MostrarSeleccionado()
    {
        if (personaje1) Debug.Log("Personaje 1 seleccionado");
        else if (personaje2) Debug.Log("Personaje 2 seleccionado");
        else if (personaje3) Debug.Log("Personaje 3 seleccionado");
        else if (personaje4) Debug.Log("Personaje 4 seleccionado");
        else if (personaje5) Debug.Log("Personaje 5 seleccionado");
        else if (personaje6) Debug.Log("Personaje 6 seleccionado");
        else if (personaje7) Debug.Log("Personaje 7 seleccionado");
        else if (personaje8) Debug.Log("Personaje 8 seleccionado");
        else if (personaje9) Debug.Log("Personaje 9 seleccionado");
        else if (personaje10) Debug.Log("Personaje 10 seleccionado");
        else if (personaje11) Debug.Log("Personaje 11 seleccionado");
        else if (personaje12) Debug.Log("Personaje 12 seleccionado");
    }
}
