using UnityEngine;

/// <summary>
/// C�mara lateral que sigue al jugador con suavizado en posici�n y rotaci�n, evitando vibraciones.
/// </summary>
public class SideCameraFollow : MonoBehaviour
{
    [Tooltip("Jugador a seguir")] public Transform target;
    [Tooltip("Offset de posici�n relativo al jugador")] public Vector3 offset = new Vector3(0, 2, -10);
    [Tooltip("Tiempo de suavizado para el movimiento")] public float smoothTime = 0.1f;
    [Tooltip("Tiempo de suavizado para la rotaci�n")] public float rotationSmoothTime = 0.1f;
    [Tooltip("�ngulo de inclinaci�n en grados (pitch)")] public float tiltAngle = 10f;
    [Tooltip("Offset adicional para el punto de mira")] public Vector3 lookAtOffset = Vector3.zero;

    private Vector3 _positionVelocity = Vector3.zero;

    void LateUpdate()
    {
        if (target == null)
            return;

        // Suavizado de posici�n
        Vector3 desiredPosition = target.position + offset;
        transform.position = Vector3.SmoothDamp(transform.position, desiredPosition, ref _positionVelocity, smoothTime);

        // Suavizado de rotaci�n
        Vector3 lookPoint = target.position + lookAtOffset;
        // Calcula la rotaci�n deseada apuntando al objetivo y aplicando tilt
        Quaternion desiredRotation = Quaternion.LookRotation(lookPoint - transform.position) * Quaternion.Euler(tiltAngle, 0, 0);
        // Interpolaci�n suave de rotaci�n
        transform.rotation = Quaternion.Slerp(transform.rotation, desiredRotation, Time.deltaTime / rotationSmoothTime);
    }
}
