using UnityEngine;
using TMPro;

public class UsernameBootstrap : MonoBehaviour
{
    [Header("UI")]
    public TextMeshProUGUI usernameLabel;   // arr�stralo desde tu Canvas
    [Header("Opcional")]
    public string loginUrl = "/login.html"; // para enviar al login si no hay sesi�n

    void Start()
    {
        // 1) Lee el username guardado por la p�gina web
        var username = BrowserStorage.GetItem("player_username");

        // 2) Si existe, mu�stralo
        if (!string.IsNullOrEmpty(username))
        {
            if (usernameLabel) usernameLabel.text = username;
            Debug.Log("Usuario autenticado: " + username);
        }
        else
        {
            Debug.LogWarning("No hay username en localStorage");
#if UNITY_WEBGL && !UNITY_EDITOR
            if (!string.IsNullOrEmpty(loginUrl))
                Application.OpenURL(loginUrl);
#endif
        }
    }
}
