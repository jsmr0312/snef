using UnityEngine;

[CreateAssetMenu(menuName = "SNEF/Shop Item", fileName = "ShopItemData")]
public class ShopItemData : ScriptableObject
{
    [Header("Datos del art�culo")]
    public string id = "consola";           // clave �nica para guardado
    public string displayName = "Consola";
    public int price = 1000;
    [TextArea] public string description = "Descripci�n...";
    public Sprite sprite;                    // imagen para la previsualizaci�n
}
