using UnityEngine;

[System.Serializable]
public class QuizQuestion
{
    [TextArea(2, 4)] public string question;

    [Tooltip("2�4 opciones")]
    public string[] options;

    [Tooltip("�ndice (0-based) de la opci�n correcta")]
    public int correctIndex;

    [Tooltip("Justificaci�n por opci�n (misma longitud que 'options'). " +
             "Para la correcta puede ir vac�o o un refuerzo positivo.")]
    [TextArea(2, 3)]
    public string[] optionJustifications;
}

[CreateAssetMenu(fileName = "NewQuizData", menuName = "Quiz/QuizData")]
public class QuizData : ScriptableObject
{
    [Tooltip("Hasta 5 preguntas (o las que necesites)")]
    public QuizQuestion[] questions;
}
