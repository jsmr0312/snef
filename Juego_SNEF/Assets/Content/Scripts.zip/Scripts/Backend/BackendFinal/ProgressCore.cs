﻿// ProgressCore.cs — CANÓNICO v2 (auto-spawn, compatible con avatar/tienda/stands)

using System;
using System.Collections.Generic;
using UnityEngine;

[DefaultExecutionOrder(-10000)]
public class ProgressCore : MonoBehaviour
{
    public static ProgressCore I { get; private set; }

    // Hacemos pública la clave para utilidades de debug externas
    public const string STORAGE_KEY = "progress-storage";

    #region Data Model (alinea con tu JSON de localStorage)
    [Serializable] public class Profile { public string avatar_id; public string username; public bool is_anon; }
    [Serializable] public class QuizProgress { public string trivia_id; public int best_score; public int attempts; public int last_time_s; }
    [Serializable] public class MinigameProgress { public string name; public int best_score; public int times_played; public int total_time_s; public string last_outcome; }

    [Serializable]
    public class StandProgress
    {
        public string stand_id;
        public string stand_type = "master";
        public string phase = "Initial";            // Initial | Waiting | PostScreens | Final
        public bool quiz_unlocked = false;
        public bool arcade_unlocked = false;
        public List<string> viewed_screens = new();
        public QuizProgress quiz = new();
        public List<MinigameProgress> minigames = new();
        public int time_spent_s = 0;
        public string last_visit_iso;
    }

    // ⬇️ RENAME: Progress -> ProgressModel
    [Serializable]
    public class ProgressModel
    {
        public Profile profile = new();
        public int puntaje = 0;
        public int presupuesto = 0;
        public List<string> store_items = new();
        public List<string> owned_items = new();
        public List<StandProgress> stands = new();
    }

    [Serializable] public class State { public ProgressModel progress = new(); }
    [Serializable] public class BootstrapState { public State state = new(); public int version = 0; }
    #endregion

    // Estado en memoria
    public BootstrapState Data { get; private set; } = new BootstrapState();

    // Atajo cómodo (evita escribir Data.state.progress en todos lados)
    public ProgressModel Progress => Data.state.progress;

    #region Bootstrap / Ciclo de vida
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void EnsureProgressCore()
    {
        if (I == null)
        {
            var go = new GameObject("ProgressCore");
            go.AddComponent<ProgressCore>();
        }
    }

    void Awake()
    {
        if (I != null) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);
        TryLoadLocal();
    }

    void TryLoadLocal()
    {
        string json = PlayerPrefs.GetString(STORAGE_KEY, "");
        if (!string.IsNullOrEmpty(json))
        {
            var local = JsonUtility.FromJson<BootstrapState>(json);
            if (local?.state?.progress != null) Data = local;
        }
    }

    public void LoadFromBootstrapJson(string json)
    {
        try
        {
            var incoming = JsonUtility.FromJson<BootstrapState>(json);
            if (incoming?.state?.progress != null)
            {
                Data = incoming;
                Debug.Log("[ProgressCore] Bootstrap cargado.");
                SaveNow("bootstrap_load");
            }
            else Debug.LogWarning("[ProgressCore] JSON sin state.progress.");
        }
        catch (Exception ex) { Debug.LogWarning("[ProgressCore] JSON inválido: " + ex.Message); }
    }

    public void SaveNow(string reason = "manual")
    {
        string json = JsonUtility.ToJson(Data);
        PlayerPrefs.SetString(STORAGE_KEY, json);
        PlayerPrefs.Save();
        Debug.Log($"[ProgressCore] Guardado ({reason}).");
    }

    public void WipeLocal()
    {
        PlayerPrefs.DeleteKey(STORAGE_KEY);
        PlayerPrefs.Save();
        Debug.Log("[ProgressCore] Progreso local borrado.");
    }
    #endregion

    #region Compat AVATAR (usado por AvatarSelectionBridge / SkipSelectionIfAlreadyChosen)
    public void SetAvatar(string avatarId)
    {
        if (string.IsNullOrWhiteSpace(avatarId)) return;
        Progress.profile.avatar_id = avatarId.Trim();
        SaveNow("set_avatar");
    }
    public string GetAvatarId() => Progress.profile?.avatar_id ?? "";
    #endregion

    #region Wallet / Items (usado por ShopUIController)
    public void SetPresupuesto(int value)
    {
        Progress.presupuesto = Mathf.Max(0, value);
        SaveNow("set_presupuesto");
    }
    public void AddPresupuesto(int delta)
    {
        Progress.presupuesto = Mathf.Max(0, Progress.presupuesto + delta);
        SaveNow("add_presupuesto");
    }
    public bool IsOwned(string itemId)
    {
        if (string.IsNullOrWhiteSpace(itemId)) return false;
        return Progress.owned_items.Contains(itemId);
    }
    public bool OwnItem(string itemId)
    {
        if (string.IsNullOrWhiteSpace(itemId)) return false;
        if (Progress.owned_items.Contains(itemId)) return false;
        Progress.owned_items.Add(itemId);
        SaveNow("own_item");
        return true;
    }
    #endregion

    #region Stands API (usado por NPCDialogueFlow / UnifiedScreenDisplay / ArcadeInteractable)
    StandProgress FindStand(string standId)
    {
        var s = Progress.stands.Find(x => x.stand_id == standId);
        if (s == null) { s = new StandProgress { stand_id = standId }; Progress.stands.Add(s); }
        return s;
    }

    public string Stand_GetPhase(string standId) => FindStand(standId).phase;

    public void Stand_SetPhase(string standId, string standType, string newPhase)
    {
        var s = FindStand(standId);
        if (!string.IsNullOrEmpty(standType)) s.stand_type = standType;
        int Rank(string p) => p == "Initial" ? 0 : p == "Waiting" ? 1 : p == "PostScreens" ? 2 : 3;
        if (Rank(newPhase) > Rank(s.phase))
        {
            s.phase = newPhase;
            SaveNow("stand_set_phase");
        }
    }

    public void Stand_UnlockQuiz(string standId)
    {
        var s = FindStand(standId);
        if (!s.quiz_unlocked) { s.quiz_unlocked = true; SaveNow("stand_unlock_quiz"); }
    }

    public void Stand_AddViewedScreen(string standId, string assetId)
    {
        if (string.IsNullOrWhiteSpace(assetId)) return;
        var s = FindStand(standId);
        if (!s.viewed_screens.Contains(assetId))
        {
            s.viewed_screens.Add(assetId);
            SaveNow("stand_add_view");
        }
    }

    public void Stand_AddTime(string standId, int seconds)
    {
        var s = FindStand(standId);
        s.time_spent_s += Mathf.Max(0, seconds);
        SaveNow("stand_add_time");
    }

    public void Stand_SetLastVisitNow(string standId)
    {
        var s = FindStand(standId);
        s.last_visit_iso = DateTime.UtcNow.ToString("o");
        SaveNow("stand_last_visit");
    }

    public bool Stand_IsArcadeUnlocked(string standId) => FindStand(standId).arcade_unlocked;
    public void Stand_UnlockArcade(string standId) { var s = FindStand(standId); if (!s.arcade_unlocked) { s.arcade_unlocked = true; SaveNow("stand_arcade_unlock"); } }
    public void Stand_LockArcade(string standId) { var s = FindStand(standId); if (s.arcade_unlocked) { s.arcade_unlocked = false; SaveNow("stand_arcade_lock"); } }
    #endregion
}
