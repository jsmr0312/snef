using UnityEngine;
public class FocusAnchor : MonoBehaviour
{
    public Transform anchor; // arrastra aqu� el hijo vac�o (FocusPoint)
}
