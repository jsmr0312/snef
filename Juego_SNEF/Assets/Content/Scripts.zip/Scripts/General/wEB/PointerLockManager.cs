using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;

public class PointerLockManager : MonoBehaviour
{
    [Tooltip("Reintenta bloquear al recuperar foco (solo si NO hay UI abierta).")]
    public bool relockOnFocus = true;

    // Marca si hay un men�/UI que necesita el cursor
    public bool uiOpen = false;

    // Si estamos esperando el primer click para poder bloquear (WebGL exige interacci�n)
    private bool pendingLockOnClick = false;

    // NUEVO: permite liberar con ESC y esperar nuevo click para relock
    [Tooltip("Si est� activo, presionar Esc libera el cursor hasta el pr�ximo click (cuando NO hay UI abierta).")]
    public bool escToUnlock = true;

#if UNITY_WEBGL && !UNITY_EDITOR
    void Awake()
    {
        // Opcional, �til para capturar teclado en el canvas
        WebGLInput.captureAllKeyboardInput = true;
    }
#endif

    void OnEnable()
    {
        // Al entrar en escena: si no hay UI, dejamos listo para bloquear con el primer click
        if (!uiOpen)
            StartCoroutine(RequestLockNextFrame());
        else
            UnlockAndShow();
    }

    IEnumerator RequestLockNextFrame()
    {
        yield return null; // espera 1 frame a que todo est� listo
        RequestLockOnNextClick();
    }

    void Update()
    {
        // Si no tenemos foco, no hacemos nada.
        if (!Application.isFocused) return;

        // NUEVO: liberar con Esc solo cuando NO hay UI abierta
        if (escToUnlock && !uiOpen && Input.GetKeyDown(KeyCode.Escape))
        {
            // Libera y muestra el cursor, y queda esperando el pr�ximo click v�lido para relock
            UnlockAndShow();
            RequestLockOnNextClick();
            return; // nada m�s este frame
        }

        // Si la UI est� abierta, mantenemos el cursor visible y no intentamos lock.
        if (uiOpen)
        {
            EnsureUnlockedVisible();
            return;
        }

        // Si estamos esperando el primer click para bloquear...
        if (pendingLockOnClick)
        {
            // No bloquees si el click es sobre UI (botones, sliders, etc.)
            if (Input.GetMouseButtonDown(0) && !IsPointerOverUI())
            {
                TryLock();
            }
        }
        else
        {
            // Ya estamos en gameplay: si por alguna raz�n se perdi� el lock, vuelve a pedirlo en el pr�ximo click
            if (Cursor.lockState != CursorLockMode.Locked)
                RequestLockOnNextClick();
        }
    }

    void OnApplicationFocus(bool focus)
    {
        if (!relockOnFocus) return;

        // Si recuperamos foco y NO hay UI, prepara para bloquear en el pr�ximo click
        if (focus && !uiOpen)
            RequestLockOnNextClick();
    }

    // ===== API p�blica para tus men�s =====

    /// Llama esto cuando abras el men� de pausa / inventario, etc.
    public void SetUIOpen(bool open)
    {
        uiOpen = open;
        if (uiOpen)
        {
            UnlockAndShow();
        }
        else
        {
            // Cerraste la UI: en WebGL hay que esperar un click para relock
            RequestLockOnNextClick();
        }
    }

    /// Si quieres forzar el desbloqueo (p.ej. al salir a men� principal)
    public void UnlockAndShow()
    {
        pendingLockOnClick = false;
        EnsureUnlockedVisible();
    }

    /// Prepara para bloquear en el pr�ximo click v�lido (no sobre UI)
    public void RequestLockOnNextClick()
    {
        pendingLockOnClick = true;
        EnsureUnlockedVisible(); // muestra el cursor hasta que el usuario haga click para volver al juego
    }

    // ===== Internos =====
    private void TryLock()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        pendingLockOnClick = false;
    }

    private void EnsureUnlockedVisible()
    {
        if (Cursor.lockState != CursorLockMode.None)
            Cursor.lockState = CursorLockMode.None;
        if (!Cursor.visible)
            Cursor.visible = true;
    }

    private bool IsPointerOverUI()
    {
        if (EventSystem.current == null) return false;
        // Esto cubre mouse en Standalone/WebGL. Si usas touch, considera EventSystem.current.IsPointerOverGameObject(touch.fingerId)
        return EventSystem.current.IsPointerOverGameObject();
    }
}
